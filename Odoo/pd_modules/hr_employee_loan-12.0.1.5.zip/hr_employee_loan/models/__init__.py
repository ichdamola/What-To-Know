# -*- coding: utf-8 -*-

from . import loan_payroll
#import prepayment_writeoff
from . import payment
from . import loan_proof
from . import hr_salary_rule
from . import hr_payslip
