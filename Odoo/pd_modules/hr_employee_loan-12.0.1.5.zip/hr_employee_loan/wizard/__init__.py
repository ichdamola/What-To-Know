# -*- coding: utf-8 -*-

from . import loan_report_wiz